import React from "react";
import axios from "axios";
import { Redirect } from "react-router";
import { useState, useEffect } from "react";
import {
  Navbar,
  Container,
  Nav,
  Row,
  Col,
  Card,
  Button,
} from "react-bootstrap";

export default function Product() {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3004/Courses").then((res) => {
      setData(res.data);
    });
  }, []);

  return (
    <div>
      <Container>
        {data.map((pro) => (
          <Col lg={12}>
            <Card className="text-center">
              <Card.Header>FEATURED COURSES</Card.Header>

              <Card.Img
                variant="top"
                width="230px"
                height="400px"
                src={pro.images}
              />
              <Card.Body>
                <Card.Title> NAME OF COURSE: {pro.cname}</Card.Title>
                <Card.Text>DESCRIPTION: {pro.descript}</Card.Text>
                <Card.Text>PRICE : {pro.price}</Card.Text>
                <Button variant="primary" size="lg">
                  ENQUIRE NOW
                </Button>
              </Card.Body>
              <Card.Footer className="text-muted">
                2 DAYS LEFT FOR THIS PRICE
              </Card.Footer>
            </Card>
          </Col>
        ))}
      </Container>
    </div>
  );
}

import React, { useState } from "react";
import {
  Button,
  Container,
  InputGroup,
  FormControl,
  Alert,
} from "react-bootstrap";
import axios from "axios";
const regForEmail = RegExp(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
const regForName = RegExp(/^[a-zA-Z]{2,100}$/);

const regForMob = RegExp(/^[6-9][0-9]{9}$/);

export default function Enquire() {
  const [state, setState] = useState();
  const [data, setdata] = useState("");

  const [errors, seterror] = useState(" ");

  const handler = (event) => {
    const { name, value } = event.target;
    switch (name) {
      case "fname":
        let error = regForName.test(value)
          ? " "
          : "First Name should be character";
        seterror(error);
        break;
      case "lname":
        let error2 = regForName.test(value)
          ? " "
          : "Last Name should be character";
        seterror(error2);

        break;
      case "mob":
        let error3 = regForMob.test(value) ? " " : "Invalid Number";
        seterror(error3);

        break;
      case "email":
        let error4 = regForEmail.test(value) ? " " : "Enter Correct Email-Id";
        seterror(error4);

        break;
    }
  };

  const validate = () => {
    let formData = {
      fName: document.getElementById("fname").value,
      lName: document.getElementById("lname").value,
      Mob: document.getElementById("mob").value,
      Email: document.getElementById("email").value,
    };
    console.log(formData);
    setState(formData);
    axios.put(`http://localhost:3004/Courses`, formData);
    alert("Form Submitted Successfully");
  };

  return (
    <div>
      <Container>
        <h1 className="text-center ">ENQUIRY FORM</h1>
        <hr />
        {errors.length > 1 && <Alert severity="warning">{errors}</Alert>}
        <InputGroup className="mb-3">
          <InputGroup.Text name="fname">First Name</InputGroup.Text>
          <FormControl name="fname" id="fname" onChange={handler} />
        </InputGroup>
        <InputGroup className="mb-3">
          <InputGroup.Text name="lname">Last Name</InputGroup.Text>
          <FormControl name="lname" id="lname" onChange={handler} />
        </InputGroup>

        <InputGroup className="mb-3">
          <InputGroup.Text name="email">Email ID</InputGroup.Text>
          <FormControl name="email" id="email" onChange={handler} />
        </InputGroup>
        <InputGroup className="mb-3">
          <InputGroup.Text name="mob">Mobile No</InputGroup.Text>
          <FormControl name="mob" id="mob" onChange={handler} />
        </InputGroup>

        <Button variant="outline-primary" onClick={validate}>
          Submit
        </Button>
        <hr />
      </Container>
    </div>
  );
}
